/*
 * spurtcommerce
 * version 3.0
 * http://www.spurtcommerce.com
 *
 * Copyright (c) 2019 piccosoft ltd
 * Author piccosoft ltd <support@piccosoft.com>
 * Licensed under the MIT license.
 */
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'currencysymbol'})
export class CurrencySymbolPipe implements PipeTransform {
  currentSymbol: any;
  constructor() {
}
  transform(value: string, obj: any): string {
    if (Math.sign(+value) === -1) {
      value = '0';
    }
    this.currentSymbol = obj;
    if (this.currentSymbol) {
      if (this.currentSymbol.position === 'right') {
        return this.formatMoney(value) + ' ' + this.currentSymbol.symbol;
      } else if (this.currentSymbol.position === 'left') {
        return this.currentSymbol.symbol + ' ' + this.formatMoney(value);
      }
    } else {
      return this.formatMoney(value);
    }
  }

  formatMoney(amount, decimalCount = 0, decimal = '.', thousands = ',') {
    try {
      decimalCount = Math.abs(decimalCount);
      decimalCount = isNaN(decimalCount) ? 2 : decimalCount;

      const negativeSign = amount < 0 ? '-' : '';

      // tslint:disable-next-line:radix
      const i: any = parseInt(amount = Math.abs(Number(amount) || 0).toFixed(decimalCount)).toString();
      const j = (i.length > 3) ? i.length % 3 : 0;

      return negativeSign + (j ? i.substr(0, j) + thousands : '') + i.substr(j).replace(/(\d{3})(?=\d)/g, '$1' + thousands) + (decimalCount ? decimal + Math.abs(amount - i).toFixed(decimalCount).slice(2) : '');
    } catch (e) {
      return amount;
    }
  }
}
