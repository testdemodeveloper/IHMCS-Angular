/*
 * spurtcommerce
 * version 3.0
 * http://www.spurtcommerce.com
 *
 * Copyright (c) 2019 piccosoft ltd
 * Author piccosoft ltd <support@piccosoft.com>
 * Licensed under the MIT license.
 */
import { ListsSandbox } from './../../../../../core/lists/lists.sandbox';
import { Component, ViewEncapsulation, OnInit, Inject, AfterViewInit } from '@angular/core';
import {SwiperConfigInterface} from 'ngx-swiper-wrapper';
import {ConfigService} from '../../../../../core/service/config.service';
import { Router } from '@angular/router';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
    selector: 'app-product-dialog',
    templateUrl: './product-dialog.component.html',
    styleUrls: ['./product-dialog.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ProductDialogComponent implements OnInit , AfterViewInit {
    // configrations
    public config: SwiperConfigInterface = {};
    // path of the image
    public imagePath: string;

    constructor(public dialogRef: MatDialogRef<ProductDialogComponent>,
                public productDetail: ListsSandbox,
                @Inject(MAT_DIALOG_DATA)
                public product: any,
                public router: Router,
                public listSandbox: ListsSandbox,
                private configService: ConfigService) {

    }
            // initially get data from config service
    ngOnInit() {
       // this.imagePath = this.configService.get('resize').imageUrl;
       this.imagePath = this.configService.getImageUrl();
    }
        // calls the function finally
    ngAfterViewInit() {
        this.config = {
            slidesPerView: 1,
            spaceBetween: 0,
            keyboard: true,
            navigation: true,
            pagination: false,
            grabCursor: true,
            loop: false,
            preloadImages: false,
            lazy: true,
            effect: 'fade',
            fadeEffect: {
                crossFade: true
            }
        };
    }

    calculatePrice(price: number, taxType: number, taxValue: number) {
        switch (taxType) {
            case 1:
                const priceWithOutTax = +price + taxValue;
                return Math.round(priceWithOutTax);
            case 2:
                const percentToAmount = price * (taxValue / 100);
                const priceWithTax = +price + percentToAmount;
                return Math.round(priceWithTax);
            default:
                return price;
        }
    }

    truncate(value: string, limit: number = 40, trail: String = '…'): string {
        let result = value || '';
        console.log('description result', result);
        if (value) {
            const words = value.split(/\s+/);
            if (words.length > Math.abs(limit)) {
                if (limit < 0) {
                    limit *= -1;
                    result = trail + words.slice(words.length - limit, words.length).join(' ');
                } else {
                    result = words.slice(0, limit).join(' ') + trail;
                }
            }
        }

        return result;
    }

    // close the popup window
    public close(): void {
        this.dialogRef.close();
    }
    closePopup(event) {
        this.close();
    }
    redirect() {
        this.close();
        this.router.navigate(['/products/productdetails', this.product.productSlug]);
    }
}

