/*
 * spurtcommerce
 * version 3.0
 * http://www.spurtcommerce.com
 *
 * Copyright (c) 2019 piccosoft ltd
 * Author piccosoft ltd <support@piccosoft.com>
 * Licensed under the MIT license.
 */
import { Component, OnInit, Input, PLATFORM_ID, Inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { SidenavMenuService } from '../sidenav-menu/sidenav-menu.service';
import { ProductControlSandbox } from '../../../../core/product-control/product-control.sandbox';
import { ProductControlService } from '../../../../core/product-control/product-control.service';
import { ConfigService } from '../../../../core/service/config.service';
import { Router } from '@angular/router';
import { ListsSandbox } from '../../../../core/lists/lists.sandbox';
import { CartSandbox } from '../../../../core/cart/cart.sandbox';
import { CartPopupComponent } from './modal/cart-popup/cart-popup.component';
import { ProductCompareSandbox } from '../../../../core/product-compare/product-compare.sandbox';
import { CommonSandbox } from '../../../../core/common/common.sandbox';
import {MatDialog} from '@angular/material/dialog';

@Component({
  selector: 'app-spurt-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss'],
  providers: [ProductControlService, ProductControlSandbox]
})
export class CartNavComponent implements OnInit {
  // path of image
  public imagePath: string;
  // product flag value
  public flagValue = '0';
  @Input()
  ngSwitch: any;
  currentUser = JSON.parse(localStorage.getItem('storeUser'));

  constructor(
    public sidenavMenuService: SidenavMenuService,
    public cartSandbox: ProductControlSandbox,
    public cartBaseSandbox: CartSandbox,
    public compareSandbox: ProductCompareSandbox,
    public router: Router,
    public listSandbox: ListsSandbox,
    public commonSandbox: CommonSandbox,
    @Inject(PLATFORM_ID) private platformId: Object,
    private configService: ConfigService,
    public dialog: MatDialog,

  ) {}

  // data from configService
  ngOnInit() {
    // this.imagePath = this.configService.get('resize').imageUrl;
    if (isPlatformBrowser(this.platformId)) {
      if (localStorage.getItem('storeUserToken')) {
        this.commonSandbox.doGetProfile();
        const subParams: any = {};
        subParams.limit = '';
        subParams.offset = 0;
        subParams.count = true;
        this.commonSandbox.getWishlistCounts(subParams);
      }
      if (localStorage.getItem('compareId')) {
        this.compareSandbox.addCompareCount(
          JSON.parse(localStorage.getItem('compareId'))
        );
      }
    }
    this.imagePath = this.configService.getImageUrl();
    const params: any = {};
    params.limit = '';
    params.offset = 0;
    params.count = true;
    if (this.currentUser) {
      this.cartBaseSandbox.GetCartListList({});
      this.cartBaseSandbox.getCartCounts(params);
      this.cartBaseSandbox.GetCartListList$.subscribe(data => {
        if (data) {
        // this.cartSandbox.clearCart();
         console.log('data.cartList', data);
         data.forEach(datas => {
          const param: any = {};
          param.totalOptions = datas._totalOptions;
          param._optionValueArray = datas._optionValueArray;
          this.cartSandbox.addItemsToCartFromDatabase(datas, param);
         });
        }
      });
    }
  }

  /**first clear the local storage data.
   * calls commonSandbox doSignout,
   * Then navigate to authentication module
   * */
  signOut() {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.clear();
      sessionStorage.clear();
    }
    this.compareSandbox.clearCompare([]);
    this.commonSandbox.doSignout();
    this.cartSandbox.clearCart();
    this.router.navigate(['/auth']);
  }

  viewCartPopup() {
    const dialogRef = this.dialog.open(CartPopupComponent, {
      panelClass: 'make-quotation'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 'success') {
      }
    });
  }
}
