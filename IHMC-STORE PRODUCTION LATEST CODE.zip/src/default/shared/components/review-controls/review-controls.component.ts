import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-review-controls',
  templateUrl: './review-controls.component.html',
  styleUrls: ['./review-controls.component.scss']
})
export class ReviewControlsComponent implements OnInit {
  @Input() ratingsList: any;

  constructor() { }

  ngOnInit() {
  }

  getShortName(fullName: string) {
    return fullName.split(' ').map(n => n[0]).join('');
  }

}
