/*
 * SpurtCommerce
 * version 3.0
 * http://www.spurtcommerce.com
 *
 * Copyright (c) 2019 PICCOSOFT
 * Author piccosoft <support@spurtcommerce.com>
 * Licensed under the MIT license.
 */
import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { ListsSandbox } from '../../../../../core/lists/lists.sandbox';
import { Subscription } from 'rxjs';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';




@Component({
  selector: 'app-view-tierprice-chart',
  templateUrl: 'view-tierprice-chart.component.html',
  styleUrls: ['view-tierprice-chart.component.scss']
})
export class ViewTierpriceChartComponent implements OnInit, OnDestroy {

  public questionList: any;
  public answer: any;
  public subscriptions: Array<Subscription> = [];
  public currency: any;

  constructor(
              public sandbox: ListsSandbox,
              @Inject(MAT_DIALOG_DATA) public data: any,
              private dialogRef: MatDialogRef<ViewTierpriceChartComponent>) {
  }

  ngOnInit() {
    this.currency = JSON.parse(localStorage.getItem('currency'));
    console.log('details', this.data);
  }

  submit() {

  }
  close() {
    this.dialogRef.close();
  }

  ngOnDestroy() {
   this.subscriptions.forEach(each => each.unsubscribe());
  }

}
