/*
 * spurtcommerce
 * version 3.0
 * http://www.spurtcommerce.com
 *
 * Copyright (c) 2019 piccosoft ltd
 * Author piccosoft ltd <support@piccosoft.com>
 * Licensed under the MIT license.
 */

// module
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterModule} from '@angular/router';
import {ReactiveFormsModule} from '@angular/forms';
import {SharedModule} from '../../shared/shared.module';
import {ComponentsModule} from '../../shared/components/index';
import {TranslateModule} from '@ngx-translate/core';
// shared module
import {NumberAcceptModule} from './../../shared/validation-directives/onlyNumber.module';

// effects
import {EffectsModule} from '@ngrx/effects';
import {AuthEffects} from '../../../core/auth/effects/auth.effect';
// component
import {SignInComponent} from './sign-in/sign-in.component';
import {AuthComponent} from './Auth/auth.component';
import {ForgotComponent} from './forgot/forgot.component';
// service
import {AuthApiService} from '../../../core/auth/auth.service';
// sandbox
import {AuthSandbox} from '../../../core/auth/auth.sandbox';
import { SocialLoginModule } from '../../../default/shared/social-login/auth.module';
// social sign in


export const routes = [
    {
        path: '', component: AuthComponent,
        children: [
            {path: '', component: SignInComponent, pathMatch: 'full'},
            {path: 'sign-in', component: SignInComponent, pathMatch: 'full'},
            {path: 'forgot', component: ForgotComponent, pathMatch: 'full'}
        ]
    },
];


/** Configurations for social login
 * provider=Key to login
 * **/
// export function getAuthServiceConfigs() {
//     const config = new AuthServiceConfig(
//         [
//             {
//                 id: FacebookLoginProvider.PROVIDER_ID,
//                 provider: new FacebookLoginProvider('442409596551509')
//             },
//             {
//                 id: GoogleLoginProvider.PROVIDER_ID,
//                 provider: new GoogleLoginProvider('761452443919-k4poofdtqosvq5kf5r7nlbdee9uroqki.apps.googleusercontent.com')
//             },
//             {
//                 id: LinkedinLoginProvider.PROVIDER_ID,
//                 provider: new LinkedinLoginProvider('cChZNFj6T5R0TigYB9yd1w')
//             },
//         ]
//     );
//     return config;
// }

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        ReactiveFormsModule,
        SharedModule,
        ComponentsModule,
        SocialLoginModule,
        EffectsModule.forFeature([AuthEffects]),
        TranslateModule.forChild(),
        NumberAcceptModule
    ],
    declarations: [
        SignInComponent,
        ForgotComponent,
        AuthComponent
    ],
    providers: [AuthApiService, AuthSandbox]
})
export class AuthenticationModule {
}
