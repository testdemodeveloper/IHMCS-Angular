/*
 * spurtcommerce
 * version 3.0
 * http://www.spurtcommerce.com
 *
 * Copyright (c) 2019 piccosoft ltd
 * Author piccosoft ltd <support@piccosoft.com>
 * Licensed under the MIT license.
 */
import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {MatSnackBar} from '@angular/material/snack-bar';
import {emailValidator, matchingPasswords} from '../../../theme/utils/app-validators';
import {AuthSandbox} from '../../../../core/auth/auth.sandbox';
import { Title } from '@angular/platform-browser';


@Component({
    selector: 'app-auth',
    templateUrl: './auth.component.html',
    styleUrls: ['./auth.component.scss']
})
export class AuthComponent implements OnInit {
    // reactive form
    public registerForm: FormGroup;
    // validation
    public submitted = false;

    constructor(public formBuilder: FormBuilder,
                public router: Router,
                public snackBar: MatSnackBar,
                public authSandbox: AuthSandbox,
                private titleService: Title) {
    }

    // Initially initialize reactive form
    ngOnInit() {
        this.titleService.setTitle('Login');

        const mobileValidationPattern = '^-?[0-9]\\d*(\\.\\d{1,2})?$';
        const nameValidationPattern = '[a-zA-Z \'-,;.]*';
        this.registerForm = this.formBuilder.group({
            'name': ['', Validators.compose([Validators.required, Validators.pattern(nameValidationPattern), Validators.minLength(3)])],
            'lastName': ['', Validators.compose([Validators.required, Validators.pattern(nameValidationPattern)])],
            'email': ['', Validators.compose([Validators.required, emailValidator])],
            'password': ['', Validators.compose([Validators.required, Validators.minLength(5)])],
            'confirmPassword': ['', Validators.compose([Validators.required])],
            'phoneNumber': ['', Validators.compose([Validators.required, Validators.pattern(mobileValidationPattern)])]
        }, {validator: matchingPasswords('password', 'confirmPassword')});

    }

    /** calls authSandbox doRegister if tthe from is valid.
     Then calls resetAllFormFields for reset **/
    public onRegisterFormSubmit(values: Object): void {
        console.log('sign up form', this.registerForm.value);
        if (this.registerForm.valid) {
            this.authSandbox.doRegister(this.registerForm.value);
            this.submitted = false;
            this.registerForm.reset();
            // this.resetAllFormFields(this.registerForm);
        } else {
            this.submitted = true;
        }
    }

    // reset the values
    resetAllFormFields(formGroup: FormGroup) {
        Object.keys(formGroup.controls).forEach(field => {
            const control = formGroup.get(field);
            if (control instanceof FormControl) {
                control.reset();
                control.clearValidators();
                control.updateValueAndValidity();
            } else if (control instanceof FormGroup) {
                this.resetAllFormFields(control);
            }
        });
    }

    // validate the reactive form
    validateAllFormFields(formGroup: FormGroup) {
        Object.keys(formGroup.controls).forEach(field => {
            const control = formGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({onlySelf: true});
            } else if (control instanceof FormGroup) {
                this.validateAllFormFields(control);
            }
        });
    }

}
