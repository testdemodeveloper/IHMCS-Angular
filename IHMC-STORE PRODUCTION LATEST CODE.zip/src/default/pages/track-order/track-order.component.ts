/*
 * spurtcommerce
 * version 3.0
 * http://www.spurtcommerce.com
 *
 * Copyright (c) 2019 piccosoft ltd
 * Author piccosoft ltd <support@piccosoft.com>
 * Licensed under the MIT license.
 */
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ListsSandbox } from '../../../core/lists/lists.sandbox';
import { Subscription } from 'rxjs';
import { Title } from '@angular/platform-browser';


@Component({
    selector: 'app-track-order',
    templateUrl: './track-order.component.html',
    styleUrls: ['./track-order.component.scss']
})
export class TrackOrderComponent implements OnInit {
   trackHistory = false;
   public trackForm: FormGroup;
   public submitted = false;
   aaa: any;
   subscription: Array<Subscription> = [];
   trackId: any;


    constructor(public formBuilder: FormBuilder,
                public listSandbox: ListsSandbox,
                private titleService: Title) { }

    ngOnInit() {
        this.titleService.setTitle('Track Order');
        this.initTrackForm();
        const array = ['a', 'b', 'c'];
        console.log(String(array));

    }
    goToTrack() {
    }
    initTrackForm() {
        this.trackForm = this.formBuilder.group({
            orderPrefixId: ['', Validators.required],
        });
     }
     public onTrackFormSubmit(values: Object): void {
        this.submitted = true;
        if (this.trackForm.valid) {
            this.trackId = this.trackForm.value['orderPrefixId'];
            this.submitted = false;
            const params: any = {};
            params.orderPrefixId = this.trackForm.value['orderPrefixId'];
            this.listSandbox.trackOrder(params);
            this.subscription.push(this.listSandbox.trackOrderDetail$.subscribe(data => {
                if (data) {
                    this.trackHistory = true;
                }
              }));

        }
    }
}
