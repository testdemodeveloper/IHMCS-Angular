import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyagain',
  templateUrl: './buyagain.component.html',
  styleUrls: ['./buyagain.component.scss']
})
export class BuyAgainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
