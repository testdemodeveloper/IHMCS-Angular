import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AccountSandbox } from '../../../../core/account/account.sandbox';
import { environment } from '../../../../environments/environment';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { ListsSandbox } from '../../../../core/lists/lists.sandbox';
import { Title } from '@angular/platform-browser';


@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.scss']
})
export class ReviewComponent implements OnInit, OnDestroy {

  public orderProductId: any;
  public imageUrl = environment.imageUrl;
  public details: any;
  private Subscription: Array<Subscription> = [];
  public currentRate = 0;
  public textError = false;
  public rattingError = false;
  public submitted = false;
  public review = '';


  constructor(public route: ActivatedRoute,
              public sandbox: AccountSandbox,
              public router: Router,
              public listSandbox: ListsSandbox,
              private titleService: Title) {
    this.route.params.subscribe(data => {
      this.orderProductId = data.id;
    });
   }

  ngOnInit() {
    this.titleService.setTitle('Reviews');
    if (this.orderProductId) {
      this.sandbox.myOrderDetails({orderProductId: this.orderProductId});
    }
    this.subscribe();
  }

  subscribe() {
    this.Subscription.push(this.sandbox.myOrderDetails$.subscribe(data => {
      if (data) {
        this.details = data;
        this.currentRate = data.rating;
        this.review = data.review;
      }
    }));
  }


  submit(text) {
    this.submitted = true;
    this.textError = false;
    this.rattingError = false;
    if (text && this.currentRate > 0) {
      const params: any = {};
      params.productId = this.details.productId;
      params.orderProductId = this.details.orderProductId;
      params.reviews = text;
      params.rating = this.currentRate;
      this.sandbox.addProductReview(params);
      this.subscribeSuccess();
    } else {
      if (!text) {
        this.textError = true;
      }
      if (this.currentRate === 0) {
        this.rattingError = true;

      }
    }
  }

  subscribeSuccess() {
    this.Subscription.push(this.sandbox.addProductReview$.subscribe(data => {
      if (data && data.status === 1 ) {
        this.router.navigate(['/account/myorders']);
      }
    }));
  }

  ngOnDestroy() {
    this.Subscription.forEach(each => each.unsubscribe());
  }

}
