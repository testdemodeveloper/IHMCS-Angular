import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { EnquiryDialogComponent } from '../enquiry-dialog/enquiry-dialog.component';
import { ListsSandbox } from '../../../../core/lists/lists.sandbox';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-service-detail',
  templateUrl: './service-detail.component.html',
  styleUrls: ['./service-detail.component.scss']
})
export class ServiceDetailComponent implements OnInit {
  contactForm: FormGroup;
  subcsription: Array<Subscription> = [];
  serviceDetail: any;
  serviceId: number;
  currentCategory: any;
  public imageUrl = environment.imageUrl;

  constructor(public formBuilder: FormBuilder, public dialog: MatDialog,
     public listSandbox: ListsSandbox, public activeRoute: ActivatedRoute) {
      activeRoute.params.subscribe(data => {
        console.log('data', data);
        if (data['serviceId']) {
          this.serviceId = +data['serviceId'];
        }
        if (data['id']) {
          this.getServiceList(data['id']);
        }
        this.currentCategory = data['category'];
      });
     }

  ngOnInit() {
  }
  public openEnquiryDialog(service) {
    const dialogRef = this.dialog.open(EnquiryDialogComponent, {
      panelClass: 'service-dialog',
      data: service

    });
  }
  getServiceList(id) {
    const params: any = {};
    params.categoryId = id;
    this.listSandbox.getServiceList(params);
    this.subscribeEvent();
  }
  subscribeEvent() {
    this.subcsription.push(this.listSandbox.serviceList$.subscribe(list => {
      console.log('list', list);
      if (list) {
        list.forEach(each => {
          if (each.serviceId === this.serviceId) {
            this.serviceDetail = each;
            console.log('serviceDetail', this.serviceDetail);

          }
        });
      }
    }));
  }
}
