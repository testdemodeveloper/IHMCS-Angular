import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { emailValidator } from '../../theme/utils/app-validators';
import { ListsSandbox } from '../../../core/lists/lists.sandbox';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.scss']
})
export class ServicesComponent implements OnInit {
  contactForm: FormGroup;

  constructor(public formBuilder: FormBuilder, public listSandbox: ListsSandbox) {}

  ngOnInit() {
  }
}
