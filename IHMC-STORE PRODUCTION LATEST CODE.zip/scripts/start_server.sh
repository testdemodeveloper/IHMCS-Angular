#!/bin/bash
cd /home/ubuntu/development
port=4000 forever start dist/server.js
